# Flux
**Write code like you write math.**

Flux is a mathematical programming language that lets you express computation exactly as it appears on paper—no boilerplate, no ceremony. Just pure mathematical clarity.

## Math Mode Syntax

### Write variables like math
No `var` keyword needed. Just assign.

```flux
x = 10;
y = 20;
print x + y;          // 30
```

### Write functions like math
Define functions using mathematical notation with automatic return.

```flux
f(x) = x^2;
print f(5);           // 25

g(a, b) = a * b + 1;
print g(3, 4);        // 13

h(x) = 2*x^3 - 5*x + 1;
print h(2);           // 7
```

## Advanced Mathematics

### 1. Vectors & Matrices
Linear algebra as first-class primitives.

```flux
F = vec(10, 0, 0);
d = vec(5, 5, 0);

W = F * d;                    // Dot product: 50

I = mat([[1, 0], [0, 1]]);
A = mat([[2, 0], [0, 2]]);
B = A + I;                    // Matrix addition
C = A * A;                    // Matrix multiplication
```

### 2. Complex Numbers
Native support for complex analysis.

```flux
z1 = complex(3, 4);           // 3 + 4i
z2 = complex(1, 2);           // 1 + 2i

print z1 + z2;                // 4 + 6i
print z1 * z2;                // -5 + 10i
print abs(z1);                // 5
print conj(z1);               // 3 - 4i
```

### 3. Calculus
Differentiation and integration built into the language.

```flux
f(x) = x^2 + 2*x + 1;

print deriv(f, 3);            // ~8.0
print integrate(f, 0, 1);     // ~2.333
```

## Quick Start

```bash
# Compile Flux
cd clox
gcc -o flux *.c -lm

# Run a Flux program
./flux program.flux

# Or start the REPL
./flux
```

## Example: Physics Simulation

```flux
// Define constants
g = 9.8;
m = 2.5;

// Kinetic energy function
KE(v) = 0.5 * m * v^2;

// Potential energy function
PE(h) = m * g * h;

// Calculate total energy
v = 10;
h = 5;
E = KE(v) + PE(h);
print E;                      // 247.5 J
```

## Philosophy

Flux eliminates the gap between mathematical notation and code:

- **No keywords** for variables (`x = 10` not `var x = 10`)
- **Function notation** matches math (`f(x) = x^2` not `fun f(x) { return x^2; }`)
- **Native math types** (vectors, matrices, complex numbers)
- **Built-in calculus** (derivatives, integrals)

---

**Flux is part of the Axiom Stack** — a neuro-symbolic framework for mathematical computation and reasoning.
